"""Test deprecated modules."""
# pylint: disable=unused-import,no-name-in-module,import-error,ungrouped-imports

import Bastion # [deprecated-module]
import rexec # [deprecated-module]

from Bastion import bastion_module # [deprecated-module]
from rexec import rexec_module # [deprecated-module]
