
.. _devpi: http://doc.devpi.net
.. _Python: http://www.python.org
.. _virtualenv: https://pypi.python.org/pypi/virtualenv
.. _virtualenv3: https://pypi.python.org/pypi/virtualenv3
.. _virtualenv5: https://pypi.python.org/pypi/virtualenv5
.. _`py.test`: http://pytest.org
.. _nosetests:
.. _`nose`: https://pypi.python.org/pypi/nose
.. _`Holger Krekel`: https://twitter.com/hpk42
.. _`pytest-xdist`: https://pypi.python.org/pypi/pytest-xdist

.. _`easy_install`: http://peak.telecommunity.com/DevCenter/EasyInstall
.. _pip: https://pypi.python.org/pypi/pip
.. _setuptools: https://pypi.python.org/pypi/setuptools
.. _`jenkins`: https://jenkins.io/index.html
.. _sphinx: https://pypi.python.org/pypi/Sphinx
.. _discover: https://pypi.python.org/pypi/discover
.. _unittest2: https://pypi.python.org/pypi/unittest2
.. _mock: https://pypi.python.org/pypi/mock/
