
tox configuration and usage examples
==============================================================================

.. toctree::
   :maxdepth: 2

   example/basic.rst
   example/pytest.rst
   example/unittest
   example/nose.rst
   example/general.rst
   example/jenkins.rst
   example/devenv.rst
   example/platform.rst
