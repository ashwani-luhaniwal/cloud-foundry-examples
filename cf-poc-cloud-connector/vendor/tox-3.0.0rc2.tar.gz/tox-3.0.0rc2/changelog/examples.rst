file ``544.feature.rst``::

    ``tox --version`` now shows information about all registered plugins - by @obestwalter.


file ``571.bugfix.rst``::

    ``skip_install`` overrides ``usedevelop`` (``usedevelop`` is an option to choose the
    installation type if the package is installed and `skip_install` determines if it should be
    installed at all) - by @ferdonline.
