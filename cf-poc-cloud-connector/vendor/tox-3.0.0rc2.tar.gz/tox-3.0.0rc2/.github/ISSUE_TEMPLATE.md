Thanks for submitting an issue!

If submitting a BUG please provide:

- [ ] Minimal reproduceable example or detailed description, assign "bug"
- [ ] OS and `pip list` output


if submitting an ENHANCEMENT issue:

- [ ] a clear problem statement with an example
- [ ] suggested change with example
- [ ] if you have want help to do a PR yourself
