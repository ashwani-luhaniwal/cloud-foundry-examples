#!/bin/bash

SRC_SID=745_REL
cp -f /bas/$SRC_SID/gen/opt/linuxx86_64/_out/libsapjwt.so sapjwt/deps/linux/x64/libsapssoext.so
cp -f /bas/$SRC_SID/gen/opt/linuxppc64/_out/libsapjwt.so sapjwt/deps/linux/ppc64/libsapssoext.so
cp -f /bas/$SRC_SID/gen/opt/linuxppc64le/_out/libsapjwt.so sapjwt/deps/linux/ppc64le/libsapssoext.so
cp -f /bas/$SRC_SID/gen/opt/darwinintel64/_out/libsapjwt.dylib sapjwt/deps/darwin/x64/libsapssoext.dylib
cp -f /bas/$SRC_SID/gen/opt/ntamd64/_out/sapjwt.dll sapjwt/deps/win32/x64/sapssoext.dll
cp -f /bas/$SRC_SID/gen/opt/ntintel/_out/sapjwt.dll sapjwt/deps/win32/ia32/sapssoext.dll
