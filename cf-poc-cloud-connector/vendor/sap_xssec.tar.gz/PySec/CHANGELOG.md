# Change Log
All notable changes to this project will be documented in this file.

This project adheres to [Semantic Versioning](http://semver.org/).

The format is based on [Keep a Changelog](http://keepachangelog.com/).

## 1.1.6 - ???

### Add
- Support for API method get_app_token

## 1.1.5 - 2018-02-19

### Update
- Update SAPJWT library to 1.0.19

## 1.0.0 - 2017-12-01

### Added
- Initial version.
