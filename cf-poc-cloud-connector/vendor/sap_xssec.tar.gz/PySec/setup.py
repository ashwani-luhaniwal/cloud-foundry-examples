""" xssec setup """
import codecs
from os import path
from setuptools import setup, find_packages

CURRENT_DIR = path.abspath(path.dirname(__file__))
VERSION_FILE_LOCATION = path.join(
    CURRENT_DIR, 'sap', 'xssec', '__version__.py')
README_LOCATION = path.join(CURRENT_DIR, 'README.md')

PACKAGE_INFO = {}
with codecs.open(VERSION_FILE_LOCATION, 'r', 'utf-8') as version_file:
    exec(version_file.read(), PACKAGE_INFO)  # pylint: disable=exec-used

with codecs.open(README_LOCATION, 'r', 'utf-8') as readme_file:
    LONG_DESCRIPTION = readme_file.read()

setup(
    name='sap_xssec',
    version=PACKAGE_INFO['__version__'],
    author='SAP',
    description=('SAP Python Security Library'),
    packages=find_packages(include=['sap*']),
    test_suite='tests',
    install_requires=[
        'requests==2.18.4',
        'six==1.11.0',
        'sap_py_jwt>=1.1.0'
    ],
    long_description=LONG_DESCRIPTION,
    classifiers=[
        # http://pypi.python.org/pypi?%3Aaction=list_classifiers
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: Implementation :: PyPy',
        'Topic :: Software Development',
        'Topic :: Software Development :: Libraries :: Python Modules',
    ],
)
